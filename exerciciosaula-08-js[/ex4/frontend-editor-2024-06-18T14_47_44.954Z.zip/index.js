// Criando um elemento h1
const h1Element = document.createElement('h1');

// Adicionando texto ao h1
h1Element.textContent = 'Sate Cafeteria';

// Inserindo o h1 no documento (dentro do body)
document.body.appendChild(h1Element);
